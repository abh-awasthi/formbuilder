<?php

$lang['username']  = "User Name";
$lang['password']  = "Password";
$lang['passconf']  = "Confirm";
$lang['email']     = "Email";
$lang['state']     = "State";
